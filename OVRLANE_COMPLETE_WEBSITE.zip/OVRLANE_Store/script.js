const products = {
  core:{name:"CORE ESSENTIAL TEE",price:2500,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=300&q=80"},
  heavy:{name:"HEAVYWEIGHT TEE",price:3200,image:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=300&q=80"},
  after:{name:"AFTER HOURS GRAPHIC",price:3500,image:"https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=300&q=80"},
  daily:{name:"DAILY UNIFORM TEE",price:2700,image:"https://images.unsplash.com/photo-1562157873-818bc0726f68?auto=format&fit=crop&w=300&q=80"},
  offduty:{name:"OFF DUTY OVERSIZED",price:3400,image:"https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=300&q=80"},
  norules:{name:"NO RULES PRINT TEE",price:3600,image:"https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=300&q=80"},
  midnight:{name:"MIDNIGHT CLUB GRAPHIC",price:3800,image:"https://images.unsplash.com/photo-1564859228273-274232fdb516?auto=format&fit=crop&w=300&q=80"},
  chaos:{name:"CHAOS THEORY PRINT",price:3900,image:"https://images.unsplash.com/photo-1503341455253-b2e723bb3dbb?auto=format&fit=crop&w=300&q=80"},
  offgrid:{name:"OFF THE GRID PRINT",price:3700,image:"https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&w=300&q=80"}
};
let cart=[];
let selectedProduct="core";
let selectedSize="M";
const $=s=>document.querySelector(s);
const money=n=>"Rs. "+n.toLocaleString("en-LK");
function showToast(message){const t=$("#toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1900)}
function updateCart(){
  const count=cart.reduce((n,item)=>n+item.qty,0);
  $("#cartCount").textContent=count;$("#drawerCount").textContent=`(${count})`;
  $("#cartTotal").textContent=money(cart.reduce((n,item)=>n+item.price*item.qty,0));
  $("#cartItems").innerHTML=cart.length?cart.map((item,i)=>`<div class="cart-row"><img src="${item.image}" alt=""><div><h4>${item.name}</h4><p>${item.size} / ${item.colour} / Qty ${item.qty}</p><button data-remove="${i}">REMOVE</button></div><strong>${money(item.price*item.qty)}</strong></div>`).join(""):`<p class="cart-empty">Your bag is empty.<br>Find your fit and add a tee.</p>`;
}
function openCart(){$("#cartDrawer").classList.add("open");$("#cartOverlay").classList.add("show");$("#cartDrawer").setAttribute("aria-hidden","false")}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#cartOverlay").classList.remove("show");$("#cartDrawer").setAttribute("aria-hidden","true")}
function openModal(id){selectedProduct=id;selectedSize="M";const p=products[id];$("#modalName").textContent=p.name;$("#modalPrice").textContent=money(p.price);document.querySelectorAll(".size-option").forEach(b=>b.classList.toggle("selected",b.textContent==="M"));$("#colourSelect").value="Black";$("#quickModal").classList.add("open");$("#quickModal").setAttribute("aria-hidden","false")}
function closeModal(){$("#quickModal").classList.remove("open");$("#quickModal").setAttribute("aria-hidden","true")}
function addSelected(){const p=products[selectedProduct],colour=$("#colourSelect").value;const found=cart.find(x=>x.id===selectedProduct&&x.size===selectedSize&&x.colour===colour);if(found)found.qty++;else cart.push({id:selectedProduct,...p,size:selectedSize,colour,qty:1});updateCart();closeModal();showToast("ADDED TO YOUR BAG ✓")}
document.querySelectorAll(".quick-add").forEach(b=>b.addEventListener("click",()=>openModal(b.dataset.product)));
document.querySelectorAll(".size-option").forEach(b=>b.addEventListener("click",()=>{selectedSize=b.textContent;document.querySelectorAll(".size-option").forEach(x=>x.classList.toggle("selected",x===b))}));
$("#modalAdd").addEventListener("click",addSelected);
$("#modalClose").addEventListener("click",closeModal);$("#modalBackdrop").addEventListener("click",closeModal);
$("#cartOpen").addEventListener("click",openCart);$("#cartClose").addEventListener("click",closeCart);$("#cartOverlay").addEventListener("click",closeCart);
$("#cartItems").addEventListener("click",e=>{const b=e.target.closest("[data-remove]");if(b){cart.splice(Number(b.dataset.remove),1);updateCart()}});
$("#checkoutBtn").addEventListener("click",()=>showToast(cart.length?"Checkout will be connected in the next step.":"YOUR BAG IS EMPTY"));
document.querySelectorAll(".filter-btn").forEach(b=>b.addEventListener("click",()=>filterProducts(b.dataset.filter,b)));
function filterProducts(filter,button){document.querySelectorAll(".filter-btn").forEach(b=>b.classList.toggle("active",b===button));document.querySelectorAll(".product-card").forEach(card=>card.hidden=!(filter==="all"||card.dataset.category===filter));checkEmpty()}
document.querySelectorAll("[data-filter-link]").forEach(a=>a.addEventListener("click",()=>{const filter=a.dataset.filterLink;const b=document.querySelector(`.filter-btn[data-filter="${filter}"]`);filterProducts(filter,b);$("#mainNav").classList.remove("open")}));
function checkEmpty(){const visible=[...document.querySelectorAll(".product-card")].some(c=>!c.hidden);$("#emptyState").hidden=visible}
$("#productSearch").addEventListener("input",()=>{const q=$("#productSearch").value.toLowerCase();document.querySelectorAll(".product-card").forEach(c=>c.hidden=!c.dataset.name.toLowerCase().includes(q));checkEmpty();document.querySelectorAll(".filter-btn").forEach(b=>b.classList.toggle("active",b.dataset.filter==="all"&&!q))});
$("#searchToggle").addEventListener("click",()=>{$("#productSearch").focus();$("#shop").scrollIntoView({behavior:"smooth"})});
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
$("#newsletterForm").addEventListener("submit",e=>{e.preventDefault();$("#newsletterMessage").textContent="Thanks for joining the OVRLANE list!";e.target.reset()});
