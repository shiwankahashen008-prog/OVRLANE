OVRLANE — starter fashion store
1. Extract this ZIP.
2. Open the extracted OVRLANE_Store folder in VS Code.
3. Open index.html in your browser (or use Live Server if installed).
4. Keep index.html, style.css and script.js in the same folder.

Included demo features:
- Responsive streetwear storefront
- Product category filters and search
- Quick add with size and colour selection
- Shopping bag with quantity and subtotal
- Newsletter demo interaction

Important:
- Product photos load from Unsplash and need an internet connection.
- Prices and product names are sample values. Edit them before publishing.
- Checkout/payment, real order processing, customer accounts and admin panel are NOT connected yet.
- Do not collect real customer/payment information on this demo site.
